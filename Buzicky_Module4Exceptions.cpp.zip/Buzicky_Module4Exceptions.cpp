//Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // Added standard exceptions
#include <exception> // Added to create custom exception

// Custom exception class creates an exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Error: Something went wrong in custom application logic.";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::logic_error("Error: Logic not working as planned"); // log_error for logic mistakes based on name of function

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;

    // Try-catch block reads input from logic function and catches standard exception
    try {
        if(do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        std::cout << "Custom Application exception caught:" << ex.what() << std::endl;
    }
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Throws custom exception created in CustomException class, caught in main method
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // If the denominator is equal to zero, we throw the runtime error with the message that we cannot divide by zero
    if (den == 0) {
        throw std:: runtime_error("Error: Cannot divide by zero");
    }
    return (num / den);
}

void do_division() noexcept {
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // Using a try-catch block to catch the exception that occurs when we attempt to divide by zero
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        std::cout << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }
    // Catches the custom exception and displays error message
    catch (const CustomException& ce)
    {
        std::cout << "Custom exception: " << ce.what() << std::endl;
    }
    // Catches the standard exception and diplays error message
    catch (const std::exception& ex)
    {
        std::cout << "Standard exception: " << ex.what() << std::endl;
    }
    // Catches any unknown exceptions and displays error message.
    catch (...)
    {
        std::cout << "Uncaught exception: " << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
