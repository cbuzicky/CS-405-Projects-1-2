// Uncomment the next line to use precompiled headers
//
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
  //FAIL();
//}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  collection->clear(); //Clear the collection to be sure it is empty

  ASSERT_TRUE(collection->empty()); // check that the collection is empty

  add_entries(1);

  EXPECT_FALSE(collection->empty()); // Negative test - check that the collection is not empty
  ASSERT_EQ(collection->size(), 1); // Check that the collection size matches the add_entries value

}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  collection->clear(); // Clear the collection
  add_entries(5);

  ASSERT_EQ(collection->size(), 5); // Check that the current size of the collection is equal to 5
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries

TEST_F(CollectionTest, MaxSizeGreaterThanEqualToSize) {

  // for loop iterates through the four collection sizes
  for (int count : {0, 1, 5, 10}) {
    collection->clear(); // Clear the collection
    collection->insert(collection->end(), count, 22); // Insert value of 22 at the end based on the count
    EXPECT_GE(collection->max_size(), collection->size());  // Checks that the max value >= current size of collection
  }
}
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries

TEST_F(CollectionTest, CapacityGreaterThanEqualToSize) {

  // for loop iterates through the four collection sizes
  for (int count : {0, 1, 5, 10}) {
    collection->clear(); // Clear the collectioj
    collection->insert(collection->end(), count, 5); // Insert value of 5 at the end based on the count
    EXPECT_GE(collection->capacity(), collection->size()); // Checks that the capacity of the collection >= the current size
  }
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreaseSize) {

  collection->clear();  // Clear the collectiojn
  size_t initial_size = collection->size();  // The initial size is the current size of the collection, which is 0
  add_entries(5); // Add entries to increase the collection from 0 to 5 entries.

  ASSERT_GT(collection->size(), initial_size); // Checks that the current collection size is greater thn the initial size
}


// TODO: Create a test to verify resizing decreases the collection

TEST_F(CollectionTest, ResizeDecreaseSize) {

  collection->clear();  // Clear the collection
  add_entries(10); // Add 10 entries to the collection
  size_t initial_size = collection->size(); //The initial size is the current size of the collection
  collection->resize(3); // Resize the collection by decreasing it from 10 to 3 entries

  ASSERT_LT(collection->size(), initial_size); // Checks that the current collection size is less than the initial size
}

// TODO: Create a test to verify resizing decreases the collection to zero

TEST_F(CollectionTest, ResizeDecreaseSizetoZero) {

  collection->clear(); // Clear the collection
  add_entries(5); // Add entries to the collection
  collection->resize(0); // Resize the collection to 0

  ASSERT_EQ(collection->size(), 0);// Check that the collection size is 0
}

// TODO: Create a test to verify clear erases the collection

TEST_F(CollectionTest, ClearErasesCollection) {

  add_entries(5);
  collection->clear(); // Clear the collection

  ASSERT_TRUE(collection->empty()); // Checks that the collection is empty
  ASSERT_FALSE(collection->size() > 0); // Checks that the collection size is not greater than 0
}

// TODO: Create a test to verify erase(begin,end) erases the collection

TEST_F(CollectionTest, EraseErasesCollection) {

  add_entries(10);
  ASSERT_FALSE(collection->empty());  // Checks that collection is not empty

  collection->erase(collection->begin(), collection->end());  // Erase all elements in the collection
  ASSERT_TRUE(collection->empty()); // Confirm collection is empty after erase
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {

  collection->clear(); // Clear the collection
  add_entries(5);

  size_t initial_size = collection->size(); // Initial size of collection = current size
  size_t initial_capacity = collection->capacity(); // Initial capacity of collection = current capacity

  collection->reserve(initial_capacity + 5);  // Increase capacity

  ASSERT_EQ(collection->size(), initial_size);            // Size should not increase, so initial size = current size of collection
  ASSERT_GE(collection->capacity(), initial_capacity);    // Capacity of collection should increase to more than the initial capacity
}


// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test

TEST_F(CollectionTest, ThrowsOutOfRangeWhenIndexOutOfBounds) {

  collection->clear();
  add_entries(4);  // Creates items at indexes 0, 1, 2, 3

  EXPECT_THROW({
    (*collection).at(5);  // This is out of bounds, since index ends at 3
  }, std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Positive test
// Checks that the initial size of the collection and current size are not equal after a resize
TEST_F(CollectionTest, SizeNotEqualAfterResize) {
  add_entries(12);  // Start with 12 entries
  size_t initial_size = collection->size(); //The initial size is the current size of the collection

  collection->resize(6);  // Resize collection from 12 to 6

  ASSERT_NE(collection->size(), initial_size);  // Initial size and current collection size should not be equal after resize
  ASSERT_EQ(collection->size(), 6);             // Current size equals resize amount
}

// Negative Test
// Checks that resizing the collection to a negative value throws a length error
TEST_F(CollectionTest, ResizeNegativeValueThrows) {

  collection->clear(); // Clears the collection

  for (int invalid_size : {-1, -5, -100}) { // For integers that are negative numbers (invalid)
    EXPECT_THROW(collection->resize(invalid_size), std::length_error);
    // Throws a length error exception if resized to negative value
    }
  }
