// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iomanip>
#include <iostream>

int main() {
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    const std::string account_number = "CharlieBrown42";
    char user_input[20];
    // String to save user input to prevent direct contact with the database
    std::string temp_input;

    // The maximum number of attempts (constant) before account is locked
    constexpr int max_attempts = 3;
    int attempt = 0; // Starting at 0 attempts

    // While loop that iterates when the user enters the value
    // If value is > 20, attempts incremented by one
    //  Loop exits after user enters value < 20 characters and displays account number
    // or if user enters > 20 characters 3 times and displays error message.
    while (attempt < max_attempts) {
        std::cout << "Enter a value (max 20 characters): ";
        // Pass user input into temp_input string
        std::getline(std::cin, temp_input);
        // If the length >= size of user_input (20), throw error and increase attempts by 1
        if (temp_input.length() >= sizeof(user_input)) {
            attempt++;
            std::cout << "Error: Input too long. You entered " << temp_input.length()
                      << " characters. Attempt " << attempt << " of " << max_attempts << ".\n" << std::endl;
        }
        else {
            // If input is valid, convert back to fixed-size char buffer and ensure null-termination occurs
            std::strncpy(user_input, temp_input.c_str(), sizeof(user_input) - 1);
            user_input[sizeof(user_input) - 1] = '\0';
            // display input along with account number
            std::cout << "You entered: " << user_input << std::endl;
            std::cout << "Account Number = " << account_number << std::endl;
            return 0;
        }
    }

    // Lock account after too many failed attempts
    std::cout << "Too many invalid attempts. Your account has been locked." << std::endl;
    return 1;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
